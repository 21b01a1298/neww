from django.apps import AppConfig


class HeartdiseaseappConfig(AppConfig):
    name = 'DiabetesDiseaseApp'
